package com.example.examplemod;

import net.minecraft.item.ItemSpade;
import net.minecraftforge.fml.common.registry.GameRegistry;

public class ItemSamShovel extends ItemSpade
{
	private String name; 
	
	public ItemSamShovel(ToolMaterial material, String itemName)
	{
		super(material);
		
		name = itemName;
		
		GameRegistry.registerItem(this, name);
		setUnlocalizedName(SamsMod.MODID + "_" + name);
	}
	
	public  String getName()
	{
		return name;
	}
	
}