package com.example.examplemod;

import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
 

public class BlockSamPlant extends Block {

	public BlockSamPlant(Material materialIn) {
		super(materialIn);
		// TODO Auto-generated constructor stub
	}

}
