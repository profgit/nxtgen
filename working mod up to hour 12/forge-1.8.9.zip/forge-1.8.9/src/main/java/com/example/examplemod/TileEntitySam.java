package com.example.examplemod;

import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.network.NetworkManager;
import net.minecraft.network.Packet;
import net.minecraft.network.play.server.S35PacketUpdateTileEntity;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.world.World;
 

public class TileEntitySam extends TileEntity implements IUpdatePlayerListBox
{
	private int counter = 0;
	private IBlockState state;

	private boolean counterEnabled = true;

	@Override
	public void update()
	{
		if (counterEnabled)
		{
			counter++;

			if (counter > 20)
			{
				counter = 0;

				state = worldObj.getBlockState(pos);

				if (!worldObj.isRemote)
					worldObj.setBlockState(pos, state.cycleProperty(BlockSamTE.NUMBER));
			}
		}
	}

	@Override
	public void readFromNBT(NBTTagCompound tag)
	{
		super.readFromNBT(tag);

		counter = tag.getInteger("counter");
		counterEnabled = tag.getBoolean("counterEnabled");
	}

	@Override
	public void writeToNBT(NBTTagCompound tag)
	{
		super.writeToNBT(tag);

		tag.setInteger("counter", counter);
		tag.setBoolean("counterEnabled", counterEnabled);
	}

	@Override
	public void onDataPacket(NetworkManager net, S35PacketUpdateTileEntity packet)
	{
		this.readFromNBT(packet.getNbtCompound());
	}

	@Override
	public Packet getDescriptionPacket()
	{
		NBTTagCompound compound = new NBTTagCompound();

		this.writeToNBT(compound);

		return new S35PacketUpdateTileEntity(pos, 1, compound);
	}

	public void editCounter()
	{
		counterEnabled = !counterEnabled;
		markDirty();
		worldObj.markBlockForUpdate(pos);
	}
	


}