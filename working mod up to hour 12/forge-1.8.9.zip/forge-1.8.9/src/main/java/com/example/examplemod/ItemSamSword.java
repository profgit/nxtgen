package com.example.examplemod;

import net.minecraft.item.ItemSword;
import net.minecraftforge.fml.common.registry.GameRegistry;

public class ItemSamSword extends ItemSword
{
	private String name; 
	
	public ItemSamSword(ToolMaterial material, String itemName)
	{
		super(material);
		
		name = itemName;
		
		GameRegistry.registerItem(this, name);
		setUnlocalizedName(SamsMod.MODID + "_" + name);
	}
	
	public  String getName()
	{
		return name;
	}
	
}