package com.example.examplemod;

import net.minecraft.block.Block;
import net.minecraft.item.Item;

public class ItemSamSeed extends Item {

	public ItemSamSeed(Block samPlant) {
		// TODO Auto-generated constructor stub
	}
 
}
