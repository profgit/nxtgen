package com.example.examplemod;
 
import net.minecraft.block.BlockContainer;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.PropertyInteger;
import net.minecraft.block.state.BlockState;
import net.minecraft.block.state.IBlockState;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.world.World;
import net.minecraftforge.fml.common.registry.GameRegistry;

public class BlockSamTE extends BlockContainer
{
	public static final PropertyInteger NUMBER = PropertyInteger.create("number", 0, 9);

	String name = "samTE";

	public BlockSamTE()
	{
		super(Material.rock);
		GameRegistry.registerBlock(this, name);
		setUnlocalizedName(SamsMod.MODID + "_" + name);

		setDefaultState(this.blockState.getBaseState().withProperty(NUMBER, Integer.valueOf(0)));

		setHardness(2F);
		setResistance(5F);
		setStepSound(soundTypeStone);

		setCreativeTab(CreativeTabs.tabBlock);
	}

	public String getName()
	{
		return name;
	}

	@Override
	public IBlockState getStateFromMeta(int meta)
	{
		return this.getDefaultState().withProperty(NUMBER, meta);
	}

	@Override
	public int getMetaFromState(IBlockState state)
	{
		return (Integer) state.getValue(NUMBER);
	}

	@Override
	protected BlockState createBlockState()
	{
		return new BlockState(this, NUMBER);
	}

	@Override
	public TileEntity createNewTileEntity(World worldIn, int meta)
	{
		return new TileEntitySam();
	}

	@Override
	public int getRenderType()
	{
		return 3;
	}
	
	@Override
	public boolean onBlockActivated(World worldIn, BlockPos pos, IBlockState state, EntityPlayer playerIn, EnumFacing side, float hitX, float hitY, float hitZ)
	{
		TileEntity entity = worldIn.getTileEntity(pos);
       
		System.out.println("1");
       
        
		if (entity != null)
		{
			System.out.println("2");
			if (entity instanceof TileEntitySam)
			{
				System.out.println("3");
				if(playerIn.isSneaking())
				{
					System.out.println("4");
					TileEntitySam samEntity = (TileEntitySam) entity;
	
					if (!worldIn.isRemote) //check if client is running
					{
						System.out.println("5");
						samEntity.editCounter();
					}
					return true;
				}
			}
		}
		return false;
	}
}
