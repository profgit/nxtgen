package com.example.examplemod;

import java.util.Set;

import com.google.common.collect.Sets;

import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.init.Blocks;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemTool;
import net.minecraft.util.BlockPos;
import net.minecraft.world.World;
import net.minecraftforge.fml.common.registry.GameRegistry;

public class ItemSamSpax extends ItemTool
{
	private static Set blocks = Sets.newHashSet(new Block[] {Blocks.planks, 
			Blocks.bookshelf, Blocks.log, Blocks.log2, Blocks.chest, Blocks.pumpkin, 
			Blocks.lit_pumpkin, Blocks.melon_block, Blocks.ladder, Blocks.clay, Blocks.dirt, 
			Blocks.farmland, Blocks.grass, Blocks.gravel, Blocks.mycelium, Blocks.sand, 
			Blocks.snow, Blocks.snow_layer, Blocks.soul_sand});

	private String name; 
	
	public ItemSamSpax(ToolMaterial material, String itemName) //for some reason others are protected
	{
		super(3.0F, material, blocks);
		name = itemName;
		GameRegistry.registerItem(this, name);
		setUnlocalizedName(SamsMod.MODID + "_" + name);
	}
	
	public  String getName()
	{
		return name;
	}
	
	@Override
	 public boolean canHarvestBlock(Block blockIn) //what it can harvest
    {
		 return blockIn == Blocks.snow_layer ? true : blockIn == Blocks.snow;
    }
	
	@Override
	public float getStrVsBlock(ItemStack stack, Block block) //what it can break
    {
        return block.getMaterial() != Material.wood && block.getMaterial() != Material.plants && 
        block.getMaterial() != Material.vine ? super.getStrVsBlock(stack, block) : 
        this.efficiencyOnProperMaterial;
    }
	
	@Override
	public boolean hitEntity(ItemStack par1ItemStack, EntityLivingBase
		par2EntityLivingBase, EntityLivingBase par3EntityLivingBase)
	{
		par1ItemStack.damageItem(1, par3EntityLivingBase);
		return true;
	}
	
	@Override 
	//how do i modify this one????
    public boolean onBlockDestroyed(ItemStack stack, World worldIn, Block blockIn, BlockPos pos, 
    	EntityLivingBase playerIn)
    {
        if ((double)blockIn.getBlockHardness(worldIn, pos) != 0.0D)
        {
            stack.damageItem(1, playerIn);
        }

        return true;
    }
	
}