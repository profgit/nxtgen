package com.example.examplemod;

import net.minecraft.item.Item;
import net.minecraft.item.Item.ToolMaterial;

public class ItemSamAxe extends Item {

	public ItemSamAxe(ToolMaterial samium, String string) {
		// TODO Auto-generated constructor stub
	}

}
