package com.example.examplemod;

import net.minecraft.item.ItemHoe;
import net.minecraftforge.fml.common.registry.GameRegistry;

public class ItemSamHoe extends ItemHoe
{
	private String name; 
	
	public ItemSamHoe(ToolMaterial material, String itemName)
	{
		super(material);
		
		name = itemName;
		
		GameRegistry.registerItem(this, name);
		setUnlocalizedName(SamsMod.MODID + "_" + name);
	}
	
	public  String getName()
	{
		return name;
	}
	
}