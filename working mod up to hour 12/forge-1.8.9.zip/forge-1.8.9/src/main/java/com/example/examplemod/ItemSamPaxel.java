package com.example.examplemod;

import java.util.Set;

import com.google.common.collect.Sets;

import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.init.Blocks;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemTool;
import net.minecraft.util.BlockPos;
import net.minecraft.world.World;
import net.minecraftforge.fml.common.registry.GameRegistry;

public class ItemSamPaxel extends ItemTool
{
	private static Set blocks = Sets.newHashSet(new Block[] {Blocks.activator_rail, 
			Blocks.coal_ore, Blocks.cobblestone, Blocks.detector_rail, Blocks.diamond_block, 
			Blocks.diamond_ore, Blocks.double_stone_slab, Blocks.golden_rail, Blocks.gold_block, 
			Blocks.gold_ore, Blocks.ice, Blocks.iron_block, Blocks.iron_ore, Blocks.lapis_block, 
			Blocks.lapis_ore, Blocks.lit_redstone_ore, Blocks.mossy_cobblestone, Blocks.netherrack, 
			Blocks.packed_ice, Blocks.rail, Blocks.redstone_ore, Blocks.sandstone, 
			Blocks.red_sandstone, Blocks.stone, Blocks.stone_slab, Blocks.planks, 
			Blocks.bookshelf, Blocks.log, Blocks.log2, Blocks.chest, Blocks.pumpkin, 
			Blocks.lit_pumpkin, Blocks.melon_block, Blocks.ladder});
	
	private String name; 
	
	public ItemSamPaxel(ToolMaterial material, String itemName) //for some reason others are protected
	{
		super(3.0F, material, blocks);
		name = itemName;
		GameRegistry.registerItem(this, name);
		setUnlocalizedName(SamsMod.MODID + "_" + name);
	}
	
	public  String getName()
	{
		return name;
	}
	
	@Override
	 public boolean canHarvestBlock(Block blockIn) //what it can harvest
    {
        return blockIn == Blocks.obsidian ? this.toolMaterial.getHarvestLevel() == 3 : 
        (blockIn != Blocks.diamond_block && blockIn != Blocks.diamond_ore ? 
        (blockIn != Blocks.emerald_ore && blockIn != Blocks.emerald_block ? 
        (blockIn != Blocks.gold_block && blockIn != Blocks.gold_ore ? 
        (blockIn != Blocks.iron_block && blockIn != Blocks.iron_ore ? 
        (blockIn != Blocks.lapis_block && blockIn != Blocks.lapis_ore ? 
        (blockIn != Blocks.redstone_ore && blockIn != Blocks.lit_redstone_ore ? 
        (blockIn.getMaterial() == Material.rock ? true : 
        (blockIn.getMaterial() == Material.iron ? true : blockIn.getMaterial() == Material.anvil)) : 
        this.toolMaterial.getHarvestLevel() >= 2) : this.toolMaterial.getHarvestLevel() >= 1) : 
        this.toolMaterial.getHarvestLevel() >= 1) : this.toolMaterial.getHarvestLevel() >= 2) : 
        this.toolMaterial.getHarvestLevel() >= 2) : this.toolMaterial.getHarvestLevel() >= 2);
    }
	
	@Override
	public float getStrVsBlock(ItemStack stack, Block block) //what it can break
    {
        return block.getMaterial() != Material.iron && block.getMaterial() != Material.web && block.getMaterial() != Material.anvil && 
        block.getMaterial() != Material.rock && block.getMaterial() != Material.wood && 
        block.getMaterial() != Material.plants && block.getMaterial() != Material.vine ? 
        super.getStrVsBlock(stack, block) : this.efficiencyOnProperMaterial;
    }
	
	@Override
	public boolean hitEntity(ItemStack par1ItemStack, EntityLivingBase
		par2EntityLivingBase, EntityLivingBase par3EntityLivingBase)
	{
		par1ItemStack.damageItem(1, par3EntityLivingBase);
		return true;
	}
	
	@Override 
	//how do i modify this one????
    public boolean onBlockDestroyed(ItemStack stack, World worldIn, Block blockIn, BlockPos pos, 
    	EntityLivingBase playerIn)
    {
        if ((double)blockIn.getBlockHardness(worldIn, pos) != 0.0D)
        {
            stack.damageItem(1, playerIn);
        }

        return true;
    }
	
}